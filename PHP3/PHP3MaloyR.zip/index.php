<!DOCTYPE html>
<html>

<body>
  <title>Geometric Sets</title>
  <h1>Geometric Sets</h1>

  <form action="functions.php" method="post">
  First number: <input type="text" name="firNum"><br>
  Ratio: <input type="text" name="ratio"><br>
  <input type="submit" />
  </form>

</body>
</html>
